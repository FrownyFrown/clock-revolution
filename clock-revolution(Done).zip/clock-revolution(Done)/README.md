# clock-revolution
이것은 시계, 그것도 무우려 디지털
This is Clock, surprisingly it's digital
